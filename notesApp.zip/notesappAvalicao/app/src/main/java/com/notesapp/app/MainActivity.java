package com.notesapp.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    public static FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    public static FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private Intent intentCadastrese;
    private Intent intentLogar;
    private Button buttonCadastrese;
    private Button buttonLogar;
    private TextInputLayout textInputLayoutEmail;
    private TextInputLayout textInputLayoutSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializarComponentes();



        buttonCadastrese.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(intentCadastrese);
            }
        });
        buttonLogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.signInWithEmailAndPassword(textInputLayoutEmail.getEditText().getText().toString(), textInputLayoutSenha.getEditText().getText().toString())
                        .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(Task<AuthResult> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(MainActivity.this, "Logando", Toast.LENGTH_LONG).show();
                                    startActivity(intentLogar);

                                }else {
                                    Toast.makeText(MainActivity.this, "Senha ou Email errado", Toast.LENGTH_LONG).show();
                                }
                            }
                        });

            }
        });
    }
    private void inicializarComponentes(){
        intentCadastrese = new Intent(MainActivity.this,CadastroActivity.class);
        intentLogar= new Intent(MainActivity.this,NoteActivity.class);;
        buttonCadastrese = findViewById(R.id.buttonRegistrer);
        buttonLogar= findViewById(R.id.buttonLogar);
        textInputLayoutEmail = findViewById(R.id.textInputEmailLogar);
        textInputLayoutSenha = findViewById(R.id.textInputSenhaLogar);
    }


}