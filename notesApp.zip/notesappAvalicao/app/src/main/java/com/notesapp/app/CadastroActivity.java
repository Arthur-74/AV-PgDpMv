package com.notesapp.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.database.DatabaseReference;
import com.notesapp.app.model.User;

import static com.notesapp.app.MainActivity.firebaseAuth;
import static com.notesapp.app.MainActivity.firebaseDatabase;

public class CadastroActivity extends AppCompatActivity {
    private TextInputLayout textInputLayoutEmail;
    private TextInputLayout textInputLayoutNome;
    private TextInputLayout textInputLayoutSenha;
    private TextInputLayout textInputLayoutSenhaConf;
    private Intent intentIrMain;
    private Button buttonRegistrerCadastro;
    private DatabaseReference databaseReferenceCreateUser = firebaseDatabase.getReference("usuarios");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        inicializarComponentes();
        cadastrarUsuario();
    }

    private void inicializarComponentes(){
        textInputLayoutEmail = findViewById(R.id.textInputEmailCadastro);
        textInputLayoutNome = findViewById(R.id.textInputName);
        textInputLayoutSenha = findViewById(R.id.textInputSenhaCadastro);
        textInputLayoutSenhaConf = findViewById(R.id.textInputSenhaConfirmar);
        buttonRegistrerCadastro = findViewById(R.id.buttonRegistrerCadastro);
        intentIrMain = new Intent(CadastroActivity.this,MainActivity.class);
    };
    private void cadastrarUsuario(){
        buttonRegistrerCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User user = new User(
                        textInputLayoutNome.getEditText().getText().toString(),
                        textInputLayoutSenha.getEditText().getText().toString(),
                        textInputLayoutEmail.getEditText().getText().toString()
                        );
                firebaseAuth.createUserWithEmailAndPassword(
                        textInputLayoutEmail.getEditText().getText().toString(),
                        textInputLayoutSenha.getEditText().getText().toString()
                ).addOnCompleteListener(CadastroActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            databaseReferenceCreateUser.push().setValue(user);//Envia para o banco de dados
                            Toast.makeText(CadastroActivity.this, "Cadastrado", Toast.LENGTH_LONG).show();
                            startActivity(intentIrMain);
                        } else {
                            Toast.makeText(CadastroActivity.this, "Revise as informações, por favor", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
    }
}