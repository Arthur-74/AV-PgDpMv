package com.notesapp.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.notesapp.app.model.Nota;

import static com.notesapp.app.MainActivity.firebaseDatabase;

public class NoteActivity extends AppCompatActivity {
    private TextView textViewDescricao;
    private TextInputLayout textInputLayoutNotas;
    private Button buttonSalvarNota;
    private DatabaseReference databaseReferenceNote = firebaseDatabase.getReference("nota");
    private DatabaseReference databaseReferenceNoteDown = firebaseDatabase.getInstance().getReference();
    private Nota nota;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        inicializarComponentes();
        buttonSalvarNota.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nota = new Nota(textInputLayoutNotas.getEditText().getText().toString());
                databaseReferenceNote.setValue(nota);



                databaseReferenceNoteDown.child("nota").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DataSnapshot> task) {

                        if (!task.isSuccessful()) {
                            Log.e("firebase", "Error getting data", task.getException());
                        }
                        else {
                            Log.d("firebase", String.valueOf(task.getResult().getValue()));
                            textViewDescricao.setText(String.valueOf(task.getResult().getValue()));
                        }
                    }
                });
            }
        });
    }

    private void inicializarComponentes(){
        textInputLayoutNotas = findViewById(R.id.textInputNota);
        buttonSalvarNota = findViewById(R.id.buttonSalvarNota);
        textViewDescricao = findViewById(R.id.textViewDescricao);
    }
}